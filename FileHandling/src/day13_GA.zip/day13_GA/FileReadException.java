package day13_GA;

public class FileReadException extends Exception {
    public FileReadException(String message) {
        super(message);
    }
}


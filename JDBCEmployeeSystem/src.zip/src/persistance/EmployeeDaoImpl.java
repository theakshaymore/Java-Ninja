package persistance;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import entity.Employee;

public class EmployeeDaoImpl implements EmployeeDao{
	private Connection connection;

	public EmployeeDaoImpl() throws ClassNotFoundException, SQLException {
		connection = GlobalConfig.getConnection();
	}

	@Override
	public List<Employee> getAllEmployees() {
		List<Employee> employees = new ArrayList<>();
		try {
			PreparedStatement preparedStatement = connection.prepareStatement("SELECT * FROM Employee01");
			ResultSet rs = preparedStatement.executeQuery();
			while (rs.next()) {
				Employee employee = new Employee();
				employee.setId(rs.getInt("eid"));
				employee.setName(rs.getString("ename"));
				employee.setAddress(rs.getString("eadd"));
				employee.setLocation(rs.getString("eloc"));
				employee.setDeptId(rs.getInt("deptid"));
				employees.add(employee);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return employees;
	}

	@Override
	public Employee getEmployeeById(int empId) {
		Employee employee = null;
		try {
			PreparedStatement preparedStatement = connection.prepareStatement("SELECT * FROM Employee01 WHERE eid=?");
			preparedStatement.setInt(1, empId);
			ResultSet rs = preparedStatement.executeQuery();
			if (rs.next()) {
				employee = new Employee();
				employee.setId(rs.getInt("eid"));
				employee.setName(rs.getString("ename"));
				employee.setAddress(rs.getString("eadd"));
				employee.setLocation(rs.getString("eloc"));
				employee.setDeptId(rs.getInt("deptid"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return employee;
	}

	@Override
	public void insertEmployee(Employee employee) {
		try {
			PreparedStatement preparedStatement = connection.prepareStatement("INSERT INTO Employee01 (ename, eadd, eloc, deptid) VALUES (?, ?, ?, ?)");
			preparedStatement.setString(1, employee.getName());
			preparedStatement.setString(2, employee.getAddress());
			preparedStatement.setString(3, employee.getLocation());
			preparedStatement.setInt(4, employee.getDeptId());
			preparedStatement.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	@Override
	public void deleteEmployee(int empId) {
		try {
			PreparedStatement preparedStatement = connection.prepareStatement("DELETE FROM Employee01 WHERE eid=?");
			preparedStatement.setInt(1, empId);
			preparedStatement.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	@Override
	public List<Employee> getEmployeesByDepartment(int deptId) {
		List<Employee> employees = new ArrayList<>();
		try {
			PreparedStatement preparedStatement = connection.prepareStatement("SELECT e.eid, e.ename, e.eadd, e.eloc, e.deptid, d.deptname FROM Employee01 e INNER JOIN Department01 d ON e.deptid=d.deptid WHERE e.deptid=?");
			preparedStatement.setInt(1, deptId);
			ResultSet rs = preparedStatement.executeQuery();
			while (rs.next()) {
				Employee employee = new Employee();
				employee.setId(rs.getInt("eid"));
				employee.setName(rs.getString("ename"));
				employee.setAddress(rs.getString("eadd"));
				employee.setLocation(rs.getString("eloc"));
				employee.setDeptId(rs.getInt("deptid"));
				employee.setDeptName(rs.getString("deptname"));
				employees.add(employee);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return employees;
	}

	@Override
	public void updateDepartment(int deptId, String deptName) {
		try {
			PreparedStatement preparedStatement = connection.prepareStatement("UPDATE Department01 SET deptname=? WHERE deptid=?");
			preparedStatement.setString(1, deptName);
			preparedStatement.setInt(2, deptId);
			preparedStatement.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
}

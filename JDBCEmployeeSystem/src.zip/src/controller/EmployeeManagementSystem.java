package controller;

import java.sql.SQLException;
import java.util.Scanner;

import entity.Employee;
import services.EmployeeService;
import services.EmployeeServiceImpl;

public class EmployeeManagementSystem {
public static void main(String[] args) throws ClassNotFoundException, SQLException {
        
        Scanner scanner = new Scanner(System.in);
        EmployeeServiceImpl employeeService = new EmployeeServiceImpl();

        
        int choice = 0;
        do {
            System.out.println("Employee Management System");
            System.out.println("--------------------------");
            System.out.println("1. Select Employee details");
            System.out.println("2. Select Employee details based on employeeid");
            System.out.println("3. Insert Employee details");
            System.out.println("4. Delete Employee details based on employeeid");
            System.out.println("5. Print Employee and department details based on departmentid");
            System.out.println("6. Update department details based deptartmentid");
            System.out.println("7. Exit");
            System.out.println("--------------------------");
            System.out.print("Enter your choice: ");
            choice = scanner.nextInt();
            scanner.nextLine(); // to consume the new line character after integer input
            
            switch (choice) {
                case 1:
                    employeeService.getAllEmployees();
                    break;
                case 2:
                    System.out.print("Enter employee id: ");
                    int empId = scanner.nextInt();
                    employeeService.getEmployeeById(empId);
                    break;
                case 3:
                    System.out.print("Enter employee name: ");
                    String empName = scanner.nextLine();
                    System.out.print("Enter employee address: ");
                    String empAdd = scanner.nextLine();
                    System.out.print("Enter employee location: ");
                    String empLoc = scanner.nextLine();
                    System.out.print("Enter department id: ");
                    int deptId = scanner.nextInt();
                    scanner.nextLine(); // to consume the new line character after integer input
                    Employee employee = new Employee();
                    employeeService.insertEmployee(employee);
                    break;
                case 4:
                    System.out.print("Enter employee id: ");
                    int employeeId = scanner.nextInt();
                    employeeService.deleteEmployee(employeeId);
                    break;
                case 5:
                    System.out.print("Enter department id: ");
                    int departmentId = scanner.nextInt();
                    employeeService.getEmployeesByDepartment(departmentId);
                    break;
                case 6:
                    System.out.print("Enter department id: ");
                    int deptID = scanner.nextInt();
                    scanner.nextLine(); // to consume the new line character after integer input
                    System.out.print("Enter new department name: ");
                    String deptName = scanner.nextLine();
                    employeeService.updateDepartment(deptID, deptName);
                    break;
                case 7:
                    System.out.println("Exiting from the application");
                    break;
                default:
                    System.out.println("Invalid choice. Please enter a valid choice.");
            }
            
            System.out.println();
            
        } while (choice != 7);
        
        scanner.close();
    }

}


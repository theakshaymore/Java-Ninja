package entity;

public class Employee {
	 private int id;
	    private String name;
	    private String address;
	    private String location;
	    private int deptId;
	    private String deptName;

	    public int getId() {
	        return id;
	    }

	    public void setId(int id) {
	        this.id = id;
	    }

	    public String getName() {
	        return name;
	    }

	    public void setName(String name) {
	        this.name = name;
	    }

	    public String getAddress() {
	        return address;
	    }

	    public void setAddress(String address) {
	        this.address = address;
	    }

	    public String getLocation() {
	        return location;
	    }

	    public void setLocation(String location) {
	        this.location = location;
	    }

	    public int getDeptId() {
	        return deptId;
	    }

	    public void setDeptId(int deptId) {
	        this.deptId = deptId;
	    }

	    public String getDeptName() {
	        return deptName;
	    }

	    public void setDeptName(String deptName) {
	        this.deptName = deptName;
	    }

	    @Override
	    public String toString() {
	        return "Employee [id=" + id + ", name=" + name + ", address=" + address + ", location=" + location + ", deptId="
	                + deptId + ", deptName=" + deptName + "]";
	    }
}

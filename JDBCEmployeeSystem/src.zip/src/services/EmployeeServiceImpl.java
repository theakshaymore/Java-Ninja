package services;

import java.sql.SQLException;
import java.util.List;

import entity.Employee;
import persistance.EmployeeDao;
import persistance.EmployeeDaoImpl;

public class EmployeeServiceImpl implements EmployeeService{
	private EmployeeDao employeeDao;

    public EmployeeServiceImpl() throws ClassNotFoundException, SQLException {
        employeeDao = new EmployeeDaoImpl();
    }

    @Override
    public List<Employee> getAllEmployees() {
        return employeeDao.getAllEmployees();
    }

    @Override
    public Employee getEmployeeById(int empId) {
        return employeeDao.getEmployeeById(empId);
    }

    @Override
    public void insertEmployee(Employee employee) {
        employeeDao.insertEmployee(employee);
    }

    @Override
    public void deleteEmployee(int empId) {
        employeeDao.deleteEmployee(empId);
    }

    @Override
    public List<Employee> getEmployeesByDepartment(int deptId) {
        return employeeDao.getEmployeesByDepartment(deptId);
    }

    @Override
    public void updateDepartment(int deptId, String deptName) {
        employeeDao.updateDepartment(deptId, deptName);
    }
}

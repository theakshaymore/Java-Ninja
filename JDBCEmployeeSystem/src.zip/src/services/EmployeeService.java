package services;

import java.util.List;

import entity.Employee;

public interface EmployeeService {
	public List<Employee> getAllEmployees();
    
    public Employee getEmployeeById(int empId);
    
    public void insertEmployee(Employee employee);
    
    public void deleteEmployee(int empId);
    
    public List<Employee> getEmployeesByDepartment(int deptId);
    
    public void updateDepartment(int deptId, String deptName);
}

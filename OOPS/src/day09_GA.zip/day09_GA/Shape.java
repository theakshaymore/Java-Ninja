package day09_GA;

abstract class Shape {

	abstract double getArea();
	
	abstract void printDetails();
}

package day09_GA;

interface AdvancedArithmetic{
	public abstract int divisorSum(int n);
}

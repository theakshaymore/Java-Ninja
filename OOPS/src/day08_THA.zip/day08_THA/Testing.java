package day08_THA;

public class Testing {

	public static void main(String[] args) {
		Football f1 = new Football();
		System.out.println(f1.getNumberOfTeamMembers());

	}

}

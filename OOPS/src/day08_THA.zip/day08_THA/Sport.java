package day08_THA;

public class Sport {

	public String getName(){
		return "Sports";
	}
	
	public String getNumberOfTeamMembers(){
		return "Each team has n players in Sports.";
	}

}

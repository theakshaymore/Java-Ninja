package day09_THA;

abstract class Book {

	protected String title;
	abstract void setTitle(String s);
	abstract String getTitle();

}

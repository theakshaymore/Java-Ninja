package day09_THA;

public class Testing {

	public static void main(String[] args) {
		
		
		MyBook b1 = new MyBook();
		b1.setTitle("Harry Potter");
		System.out.println(b1.getTitle());

	}

}

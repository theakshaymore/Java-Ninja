package day07.day07;

public class StudentGrades {

	public static void main(String[] args) {
		System.out.println("Student Grade");
		Student student = new Student("akshay", 80,80,90);
		
		System.out.println("Grade: " + Result.resultCalculator(student));
		

	}

}

package day3;

public class RussianMul {
	public static void main(String[] args){

		int num1 =11, num2=12;
		System.out.print(getProduct(num1, num2));

	}
	public static int getProduct(int num1, int num2) {
        // first edge-case
        if (num1 <= 0 || num2 <= 0) {
            return -1;
        }
	        
        // multiplication
        int prod = 0;
        while (num1 > 0) {
            if (num1 % 2 != 0) {
                prod += num2;
            }
            num1 /= 2;
            num2 *= 2;
        }
        
        
        return prod;
	    }
	
}

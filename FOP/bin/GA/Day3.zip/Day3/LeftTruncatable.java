package day3;

import java.util.*;
public class LeftTruncatable {

	public static void main(String[] args){
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter first number: ");
		int start = sc.nextInt();
		
		System.out.println("Enter second number: ");
		int end = sc.nextInt();
		
       
        System.out.println(getCountOfLeftTruncatablePrimes(start, end));
    }
	
	public static boolean isPrime(int n) {
		if (n <= 1) {
            return false;
        }
        for (int i = 2; i <= n/2; i++) {
            if (n % i == 0) {
                return false;
            }
        }
        return true;
    }
	
	public static boolean isLeftTruncatablePrime(int n) {
		if (n < 10) {
            return isPrime(n);
        }
        if (!isPrime(n)) {
            return false;
        }
        int num = n;
        while (num > 9) {
        	int digits = (int) Math.log10(num) + 1;
        	int divisor = (int) Math.pow(10, digits - 1);
        	num = num % divisor;
            if (!isPrime(num)) {
                return false;
            }
        }
        return true;
    }
	
	public static int getCountOfLeftTruncatablePrimes(int start, int end) {
		// clecking all edge-case metioned		
        if (start > end) {
            return -1;
        }
        if (start < 0 || end < 0) {
            return -2;
        }
        if (start == 0 || end == 0) {
            return -3;
        }
       
        int count = 0;
        for (int i = start; i <= end; i++) {
            if (isLeftTruncatablePrime(i)) {
                count++;
            }
        }
        return count;
    }

}

public class GAProgram02 {
    public static void main(String[] args) {
        String dateOfBirth = "27-JUL-2010";
        int luckyNumber = getLuckyNumber(dateOfBirth);
        if (luckyNumber != -1) {
            System.out.println("Lucky number: " + luckyNumber);
        } else {
            System.out.println("invalid date format");
        }

    }

    public static int convertMMMtoMM(String month) {
        String[] months = { "JAN", "FEB", "MAR", "APR", "MAY", "JUN", "JUL", "AUG", "SEP", "OCT", "NOV", "DEC" };
        month = month.toUpperCase();
        for (int i = 0; i < months.length; i++) {
            if (months[i].equals(month)) {
                return i + 1;
            }
        }
        return -1;
    }

    public static int getSumOfDigits(int n) {
        int sum = 0;
        while (n > 0) {
            sum += n % 10;
            n /= 10;
        }
        return sum;
    }

    public static int getLuckyNumber(String dateOfBirth) {
        String[] parts = dateOfBirth.split("-");
        if (parts.length != 3) {
            return -1;
        }
        int day = Integer.parseInt(parts[0]);
        int month = convertMMMtoMM(parts[1]);
        int year = Integer.parseInt(parts[2]);
        int sum = getSumOfDigits(day) + getSumOfDigits(month) + getSumOfDigits(year);
        while (sum > 9) {
            sum = getSumOfDigits(sum);
        }
        return sum;
    }

}

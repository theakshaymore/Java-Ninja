public class GAProgram01 {
    public static void main(String[] args) {
        String[] words = { "South Africa", "Afghanistan", "Sri Lanka", "New Zealand", "West Indies", "England", "India",
                "Australia", "Pakistan", "Bangladesh" };
        String pattern = "an";

        String[] result = getWordsContainsPattern(words, pattern);

        if (result == null) {
            System.out.println("no match");
        } else {
            for (int i = 0; i < result.length; i++) {
                System.out.print(result[i]);
                if (i != result.length - 1) {
                    System.out.println(", ");
                }
            }

        }
    }

    public static String[] getWordsContainsPattern(String[] words, String pattern) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < words.length; i++) {
            if (words[i].toUpperCase().contains(pattern.toUpperCase())) {
                sb.append(words[i].toUpperCase()).append("\n");
            }
        }
        if (sb.length() == 0) {
            return null;
        }
        return sb.toString().split("\n");
    }

}

package day05;

import java.util.Scanner;

public class TOAProgram02 {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        System.out.println("Enter String: ");
        String s = sc.nextLine();
        // String s = "akshay more";

        System.out.println(reverse(s));

    }

    public static String reverse(String s) {
        if (s == null || s == "") {
            return null;
        }

        String[] words = s.split(" ");

        StringBuilder result = new StringBuilder();

        for (int i = 0; i < words.length; i++) {
            String word = words[i];
            StringBuilder reversedWord = new StringBuilder(word).reverse();
            result.append(reversedWord).append(' ');
        }

        return result.toString().trim();
    }

}

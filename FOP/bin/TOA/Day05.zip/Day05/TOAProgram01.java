package day05;

import java.util.*;

public class TOAProgram01 {

    public static void main(String[] args) {

        // String s = "ANT";
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter String: ");
        String s = sc.nextLine();

        if (isValidString(s)) {
            if (isPositiveString(s)) {
                System.out.println("positive string");
            } else {
                System.out.println("Not a positive string");
            }
        } else {
            System.out.println("Invalied string");
        }

    }

    public static boolean isPositiveString(String s) {

        if (s == null || s == "") {
            return false;
        }

        s = s.toLowerCase();
        for (int i = 1; i < s.length(); i++) {
            if (s.charAt(i) < s.charAt(i - 1)) {
                return false;
            }
        }
        return true;
    }

    public static boolean isValidString(String s) {

        if (s == null || s == "") {
            return false;
        }

        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (!(c >= 'a' && c <= 'z') && !(c >= 'A' && c <= 'Z')) {
                return false;
            }
        }

        return true;
    }

    //
}

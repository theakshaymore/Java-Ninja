package day06;

import java.util.Scanner;

public class THAProgram01 {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        System.out.print("Enter a time: ");
        String date = sc.nextLine();

        if (isValidTime(date)) {
            System.out.println("Valid Date");
        } else {
            System.out.println("Invalid Date");
        }
    }

    public static boolean isValidTime(String date) {

        String[] s = date.split(":");
        if (s.length != 3) {
            return false;
        }

        int hrs = Integer.valueOf(s[0]);
        int min = Integer.valueOf(s[1]);
        int sec = Integer.valueOf(s[2]);

        if (hrs < 0 || hrs > 23) {
            return false;
        }
        if (min < 0 || min > 59) {
            return false;
        }
        if (sec < 0 || sec > 59) {
            return false;
        }

        return true;
    }

}

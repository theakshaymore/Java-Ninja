package day06;

import java.util.Scanner;

public class THAProgram02 {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        System.out.print("Enter the number: ");
        double num = sc.nextDouble();

        String sum = concateSumOfDigits(num);
        System.out.println(sum);

    }

    public static String concateSumOfDigits(double num) {

        String[] parts = String.valueOf(num).split("\\.");

        int sumOfLeft = getSumOfDigits(Integer.valueOf(parts[0]));
        int sumOfRight = getSumOfDigits(Integer.valueOf(parts[1]));

        return (sumOfLeft + ":" + sumOfRight);

    }

    public static int getSumOfDigits(int num) {
        int sum = 0;
        while (num > 0) {
            sum += num % 10;
            num /= 10;
        }
        return sum;
    }

}

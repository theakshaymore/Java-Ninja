

import java.util.*;
public class AmicablePairs {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter start number: ");
		int start = sc.nextInt();
		System.out.println("Enter end number: ");
		int end = sc.nextInt();
//		int start = 100, end = 1000;
		
		System.out.print(sumOfAmicablePairs(start, end));

	}
	
	
	public static int sumOfAmicablePairs(int start, int end){
		 int sum = 0;
	        for (int i = start; i <= end; i++) {
	            int a = i;
	            int b = getSumOfProperDivisors(a);
	            if (a != b && getSumOfProperDivisors(b) == a) {
	                sum += a;
	            }
	        }
	        return sum;
	}
	
	
	public static int getSumOfProperDivisors(int n){
		int sum = 0;
        for (int i = 1; i < n; i++) {
            if (n % i == 0) {
                sum += i;
            }
        }
        return sum;
	}

}

package day3.TOA;

public class SecondMax {

	public static void main(String[] args) {
		
		int num = 82394;
		System.out.print(findSecondmaxDigit(num));
	}
	
	public static int findSecondmaxDigit(int num){
		if(num <= 0){
			return -1;
		}
		int max= 0, secondMax = 0;
		while(num > 0){

			int digit = num % 10;
			if(digit > max){
				secondMax = max;
				max = digit;
			}else if(digit > secondMax){
				secondMax = digit;
			}
			
			num = num / 10;
		}
		return secondMax;
	}

}
